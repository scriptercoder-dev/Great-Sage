"""Hardware discovery used to adapt Great Sage to the machine.

The scan is deliberately cheap and best-effort. NVIDIA/CUDA is used when
available. Other machines remain fully usable through CPU inference; the
application never refuses to start just because CUDA is unavailable.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from typing import Any, Dict

_CACHE = None


def scan_gpu(refresh: bool = False) -> Dict[str, Any]:
    global _CACHE
    if _CACHE is not None and not refresh:
        return dict(_CACHE)

    info: Dict[str, Any] = {
        "available": False,
        "name": "CPU",
        "vram_mb": 0,
        "index": 0,
        "cuda": False,
        "backend": "cpu",
        "tier": "cpu",
    }

    # Prefer torch because it is what the local voice stack actually uses.
    try:
        import torch
        if torch.cuda.is_available():
            idx = 0
            props = torch.cuda.get_device_properties(idx)
            total = int(props.total_memory / (1024 * 1024))
            info.update({
                "available": True,
                "cuda": True,
                "name": torch.cuda.get_device_name(idx),
                "vram_mb": total,
                "index": idx,
                "backend": "cuda",
            })
    except Exception:
        pass

    # nvidia-smi is a useful fallback and is much cheaper than installing
    # another hardware-probing package.
    if not info["available"] and shutil.which("nvidia-smi"):
        try:
            p = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=3,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            line = (p.stdout or "").strip().splitlines()[0]
            name, mb = [x.strip() for x in line.split(",", 1)]
            info.update({
                "available": True,
                "name": name,
                "vram_mb": int(float(mb)),
                "backend": "nvidia-smi",
            })
        except Exception:
            pass

    vram = int(info["vram_mb"])
    if not info["available"]:
        info["tier"] = "cpu"
    elif vram >= 12288:
        info["tier"] = "high"
    elif vram >= 8192:
        info["tier"] = "medium-high"
    elif vram >= 6144:
        info["tier"] = "medium"
    elif vram >= 4096:
        info["tier"] = "entry"
    else:
        info["tier"] = "low"

    info["cpu_threads"] = os.cpu_count() or 1
    _CACHE = dict(info)
    return info


def whisper_profile(language: str = "en") -> Dict[str, Any]:
    """Choose a faster-whisper profile for whatever hardware is available.

    NVIDIA/CUDA gets the larger model when VRAM permits. Machines without a
    usable CUDA device use CPU automatically; this is slower but keeps STT
    functional on AMD, Intel, integrated graphics and CPU-only PCs.
    """
    g = scan_gpu()
    if g.get("cuda"):
        if g["vram_mb"] >= 6144:
            return {
                "model": "large-v3-turbo",
                "device": "cuda",
                "compute_type": "float16" if g["vram_mb"] >= 8192 else "int8_float16",
            }
        if g["vram_mb"] >= 4096:
            return {
                "model": "small",
                "device": "cuda",
                "compute_type": "int8_float16",
            }
        return {"model": "base", "device": "cuda", "compute_type": "int8_float16"}

    # CPU fallback: int8 is supported by CTranslate2 on Windows CPUs and
    # keeps memory use reasonable. Use the English model for English and the
    # multilingual model for every other language.
    model = "base.en" if (language or "en").lower() == "en" else "base"
    return {
        "model": model,
        "device": "cpu",
        "compute_type": "int8",
    }


def ollama_profile() -> Dict[str, Any]:
    """Conservative Ollama defaults based on available VRAM."""
    g = scan_gpu()
    v = int(g["vram_mb"])
    if v >= 12288:
        return {"num_ctx": 12288}
    if v >= 8192:
        return {"num_ctx": 10240}
    if v >= 6144:
        return {"num_ctx": 8192}
    if v >= 4096:
        return {"num_ctx": 6144}
    return {"num_ctx": 4096}
