"""Local speech-to-text via faster-whisper, adapted to the detected GPU.

The Whisper model is loaded lazily and kept resident.  On CUDA machines the
profile is selected from VRAM; CPU-only machines stay on the smaller models
so startup and transcription remain usable.
"""
import logging
import os
import sys

import numpy as np

log = logging.getLogger(__name__)

_ENGLISH_MODEL = "base.en"
_MULTILINGUAL_MODEL = "base"

_model = None
_model_profile = None
_dll_dirs_registered = False
# FIX (perf audit): once CUDA fails once this process, stop retrying it.
# Without this, _get_model() re-ran whisper_profile() on every single
# transcribe() call, which always suggests CUDA again (hardware.py has no
# memory of the earlier failure) - so every voice input reloaded the full
# GPU model from scratch, failed on the missing cuBLAS/cuDNN DLL, then
# reloaded the CPU model from scratch too. That double reload, every
# single time you talked, is what made STT feel slow/stuck.
_cuda_broken = False


def _register_cuda_dll_dirs():
    """Make sure Windows can find cuDNN/cuBLAS when ctranslate2 loads.

    (perf audit fix - STT running on GPU)

    ctranslate2's Windows wheel ships its own `cudnn64_9.dll`, which is
    only a thin dispatcher: the actual cuDNN sub-libraries
    (cudnn_ops64_9.dll, cudnn_cnn64_9.dll, cudnn_graph64_9.dll, ...) and
    cuBLAS are NOT bundled with it.

    FIX (round 2): the first version of this function only registered
    torch's own `torch/lib` folder. Modern pip torch wheels (2.1+) do NOT
    bundle cuBLAS/cuDNN inside torch/lib either - they depend on separate
    `nvidia-cublas-cuXX`, `nvidia-cudnn-cuXX`, `nvidia-cufft-cuXX`, etc.
    packages, whose actual .dll files live under
    `site-packages/nvidia/<component>/bin/`. That's exactly the
    `cublas64_12.dll is not found` error seen in testing - torch/lib was
    registered, but it was never where that DLL actually lives. This now
    scans site-packages for every `nvidia/*/bin` folder and registers
    each one, which is the standard fix for this exact faster-whisper /
    ctranslate2 / Windows problem.

    Since Windows Python 3.8+ does not consult PATH when resolving a
    native library's own DLL dependencies (same root cause already
    documented for FFmpeg/torchcodec in this project's NOTES.md), simply
    having the right DLLs *somewhere* on disk is not enough -
    `os.add_dll_directory()` is the actual fix.

    Best-effort and safe everywhere: no-ops on non-Windows, and any
    failure here just means STT falls back to CPU rather than crashing.
    """
    global _dll_dirs_registered
    if _dll_dirs_registered or sys.platform != "win32":
        return
    _dll_dirs_registered = True
    candidates = []
    try:
        import torch
        torch_dir = os.path.dirname(os.path.abspath(torch.__file__))
        candidates.append(os.path.join(torch_dir, "lib"))
        site_packages = os.path.dirname(torch_dir)
    except Exception:
        site_packages = None
    try:
        import ctranslate2
        candidates.append(os.path.dirname(os.path.abspath(ctranslate2.__file__)))
    except Exception:
        pass
    # The split nvidia-*-cuXX packages: site-packages/nvidia/<name>/bin/*.dll
    if site_packages and os.path.isdir(os.path.join(site_packages, "nvidia")):
        nvidia_root = os.path.join(site_packages, "nvidia")
        try:
            for entry in os.listdir(nvidia_root):
                bin_dir = os.path.join(nvidia_root, entry, "bin")
                if os.path.isdir(bin_dir):
                    candidates.append(bin_dir)
        except Exception:
            log.exception("Could not scan %s for CUDA DLLs", nvidia_root)
    seen = set()
    for path in candidates:
        if path and path not in seen and os.path.isdir(path):
            seen.add(path)
            try:
                os.add_dll_directory(path)
                log.info("Registered DLL directory for CUDA/cuDNN lookup: %s", path)
            except Exception:
                log.exception("Could not register DLL directory: %s", path)
    if not seen:
        log.warning(
            "No CUDA DLL directories found to register - if GPU STT fails, "
            "check that torch and nvidia-cublas-cuXX/nvidia-cudnn-cuXX are "
            "actually installed in this environment."
        )


def _cpu_profile(language: str) -> dict:
    return {
        "model": "base.en" if (language or "en").lower() == "en" else "base",
        "device": "cpu",
        "compute_type": "int8",
    }


def _get_model(language: str):
    global _model, _model_profile, _cuda_broken
    _register_cuda_dll_dirs()
    from great_sage.core.hardware import whisper_profile
    # FIX (perf audit): once CUDA has failed this process, go straight to
    # CPU instead of asking hardware.py again - it has no way to know
    # CUDA already failed and will keep suggesting it every time,
    # triggering a full reload of the (large) GPU model on every call
    # just to fail again a moment later.
    profile = _cpu_profile(language) if _cuda_broken else whisper_profile(language)
    # Keep the profile stable for the process. A language change may require
    # a different model, so compare all meaningful fields.
    key = tuple(profile.items())
    if _model is None or _model_profile != key:
        from faster_whisper import WhisperModel
        log.info("Loading Whisper profile: %s", profile)
        try:
            _model = WhisperModel(
                profile["model"],
                device=profile["device"],
                compute_type=profile["compute_type"],
            )
        except Exception:
            # If a packaged CTranslate2 build cannot use CUDA on a particular
            # NVIDIA driver/GPU, retry once on CPU instead of killing STT.
            if profile["device"] != "cpu":
                log.exception("Whisper CUDA load failed; falling back to CPU")
                _cuda_broken = True
                profile = _cpu_profile(language)
                _model = WhisperModel(
                    profile["model"], device="cpu", compute_type="int8"
                )
            else:
                raise
        # Store the profile actually used (including the CPU fallback).
        _model_profile = tuple(profile.items())
    return _model


def _force_cpu_model(language: str):
    global _model, _model_profile, _cuda_broken
    _cuda_broken = True
    profile = _cpu_profile(language)
    key = tuple(profile.items())
    # FIX (perf audit): don't reload if we're already on the right CPU
    # model - transcribe() used to call this unconditionally on every
    # CUDA failure, reloading the CPU model from scratch every time too.
    if _model is not None and _model_profile == key:
        return _model
    from faster_whisper import WhisperModel
    log.warning("Whisper GPU inference unavailable; switching STT to CPU: %s", profile)
    _model = WhisperModel(profile["model"], device="cpu", compute_type="int8")
    _model_profile = key
    return _model


def transcribe(audio: np.ndarray, language: str = "en") -> str:
    """Transcribe 16 kHz mono float32 audio."""
    if audio.size == 0:
        return ""
    model = _get_model(language)

    def _run(current_model):
        segments, info = current_model.transcribe(
            audio,
            language=language,
            beam_size=3,
            best_of=3,
            temperature=0.0,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 350},
            condition_on_previous_text=False,
        )
        # faster-whisper performs the actual CUDA inference while this
        # generator is consumed, so the exception may happen here rather
        # than inside WhisperModel(...).
        text = " ".join(seg.text.strip() for seg in segments if seg.text.strip()).strip()
        return text, info

    try:
        text, info = _run(model)
    except Exception as exc:
        message = str(exc).lower()
        cuda_failure = any(token in message for token in (
            "cublas", "cudnn", "cuda", "cudart", "library",
        ))
        if getattr(_model_profile, "__iter__", None) and dict(_model_profile).get("device") != "cpu" and cuda_failure:
            log.warning("Whisper CUDA inference failed (%s); retrying transcription on CPU", exc)
            model = _force_cpu_model(language)
            text, info = _run(model)
        else:
            raise
    seconds = audio.size / 16000.0
    if text:
        log.info("Transcribed %.1fs (%s): %r", seconds, getattr(info, "language", language), text)
    else:
        log.warning("Transcribed %.1fs but got no text.", seconds)
    return text
